# JavaScript-LightOnOff
Description - A simple app powered by JavaScript in which you can Turn On and Off a light!
Devoloper - CodeBuddySurej(Surej S)
Languages Used - HTML , CSS , JAVASCRIPT
Code Editor Used - Visual Studio Code
